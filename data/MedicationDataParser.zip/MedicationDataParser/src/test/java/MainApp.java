import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.parser.Parser;
import org.json.simple.JSONObject;

import java.io.*;

/**
 * Created by ALEX on 20/12/14.
 */
public class MainApp {

    public static void main(String[] args)
    {


        JSONObject zdravila = new JSONObject();
        String[] primeriZdravil = {"Aspirin", "Amoxil", "Avelox", "Omnicef", "Percogesic", "Tamiflu", "BeFlex"};


        for(int iter = 0; iter < primeriZdravil.length; iter++) {
            String url = "http://www.drugs.com/search.php?searchterm=" + primeriZdravil[iter];
            System.out.println(url);
            try {
                String summary, description, sideEffects;

                String htmlRes1 = Jsoup.connect(url).data("limit", "all").get().outerHtml();
                Document doc = Parser.parse(htmlRes1, url);
                JSONObject podatki = new JSONObject();

                Element prviZadetek = doc.getElementsByClass("snippet").first();
                Element prviZadetekURLTag = prviZadetek.getElementsByTag("a").get(0);
                String prviZadetekURL = prviZadetekURLTag.attr("abs:href");

                String htmlRes2 = Jsoup.connect(prviZadetekURL).data("limit", "alL").get().outerHtml();
                Document doc2 = Parser.parse(htmlRes2, prviZadetekURL);

                StringBuilder sb = new StringBuilder(doc2.getAllElements().toString());
                sb.delete(0, sb.indexOf("<p class=\"drug-subtitle\""));

                // glavne informacije - sinonimi in proizvajalci
                int subtitleEnd = sb.indexOf("</p>") + 4;
                summary = sb.substring(0, subtitleEnd);
                sb.delete(0, subtitleEnd);


                // hotfix for empty drug-subtitle class
                if(summary.indexOf("></p>")!=-1)
                {
                    sb.delete(0, sb.indexOf("<p class=\"drug-subtitle\""));
                    subtitleEnd = sb.indexOf("</p>") + 4;

                    summary = sb.substring(0,subtitleEnd);
                }

                // opis zdravila
                sb.delete(0, sb.indexOf("<p itemprop=\"desc"));
                int descEnd = sb.indexOf("<a id=");
                description = sb.substring(0, descEnd);

                // stranski učiniki
                sb.delete(0, sb.indexOf("<a id=\"side-effects\""));
                sb.delete(0, sb.indexOf("<h2>"));
                int sideEffectsEnd = sb.indexOf("<div");
                sideEffects = sb.substring(0, sideEffectsEnd);
                 /*
                System.out.println(summary);
                System.out.println(description);
                System.out.println(sideEffects);
                 */
                podatki.put("summary", summary);
                podatki.put("description", description);
                podatki.put("sideEffects", sideEffects);

                zdravila.put(primeriZdravil[iter], podatki);

            } catch (IOException e) {
                e.printStackTrace();
            }

        }

        PrintWriter writer = null;
        try {
            writer = new PrintWriter("zdravila.json", "UTF-8");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        writer.println(zdravila);

        writer.close();
    }

}
